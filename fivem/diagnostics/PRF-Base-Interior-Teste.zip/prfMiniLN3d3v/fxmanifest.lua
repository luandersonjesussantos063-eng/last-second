fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'
version '1.0.1-interior-test'

data_file 'DLC_ITYP_REQUEST' 'stream/YTYPPRFln3d3v.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/PRFMLOMINIBASE3D3V.ytyp'

dependency '/assetpacks'
