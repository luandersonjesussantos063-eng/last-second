fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'
version '1.0.0-exterior-diagnostic'

data_file 'DLC_ITYP_REQUEST' 'stream/YTYPPRFln3d3v.ytyp'

dependency '/assetpacks'
